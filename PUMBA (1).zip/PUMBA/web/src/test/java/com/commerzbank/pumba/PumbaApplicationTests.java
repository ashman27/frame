package com.commerzbank.pumba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PumbaApplicationTests {

  @Test
  void contextLoads() {}
}
