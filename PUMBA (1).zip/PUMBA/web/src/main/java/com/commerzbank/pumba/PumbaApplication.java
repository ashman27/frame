package com.commerzbank.pumba;

import com.commerzbank.frame.common.ioc.context.support.FramePropertySourcesPlaceholderConfigurer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

/**
 * Entrypoint of the application.
 *
 * @author FRAME
 */
@SpringBootApplication
@ComponentScan(basePackages = {"com.commerzbank.pumba", "com.commerzbank.frame"})
public class PumbaApplication {

  public static void main(String[] args) {
    SpringApplication.run(PumbaApplication.class, args);
  }

  @Bean
  public static FramePropertySourcesPlaceholderConfigurer
      framePropertySourcesPlaceholderConfigurer() {
    return new FramePropertySourcesPlaceholderConfigurer();
  }
}
