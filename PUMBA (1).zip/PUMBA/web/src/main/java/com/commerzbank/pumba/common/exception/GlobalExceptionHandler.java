package com.commerzbank.pumba.common.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Global handler for exceptions that may occur in this application's {@link RestController}s
 * utilizing Spring's controller advice approach (see
 * https://docs.spring.io/spring-framework/docs/current/reference/html/web.html#mvc-ann-controller-advice).
 *
 * <p>Can be extended to handle additional custom exceptions to the application.
 *
 * @author FRAME
 */
@RestControllerAdvice(annotations = {RestController.class})
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
  /**
   * Handles upcoming {@link AccessDeniedException}s in case of unauthorized access on (business)
   * methods, which are annotated with {@code @PreAuthorize} or {@code @PostAuthorize}.
   *
   * @param ex Incoming authorization exception to be handled.
   * @param request Incoming web request.
   * @return A {@link ResponseEntity} holding this error's attributes as timestamp, status, error,
   *     path, etc.
   */
  @ExceptionHandler({AccessDeniedException.class})
  public ResponseEntity<Object> handleAccessDeniedException(Exception ex, WebRequest request) {
    return handleExceptionInternal(
        ex, ex.getMessage(), new HttpHeaders(), HttpStatus.FORBIDDEN, request);
  }
}
