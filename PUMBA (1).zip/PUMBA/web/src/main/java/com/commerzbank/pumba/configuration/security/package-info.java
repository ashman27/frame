/** Contains the classes representing the security configuration of the application. */
package com.commerzbank.pumba.configuration.security;
