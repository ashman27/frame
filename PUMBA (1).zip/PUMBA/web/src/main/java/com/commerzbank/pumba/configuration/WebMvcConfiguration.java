package com.commerzbank.pumba.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Spring Web MVC configuration adding a custom prefix for requests to REST controllers, i.e.
 * classes annotated with {@link RestController}, so that they can only be called if that prefix is
 * appended to the request mapping.
 *
 * @author FRAME
 */
@Configuration
public class WebMvcConfiguration implements WebMvcConfigurer {

  /** Custom prefix to be appended to the request mapping for a {@link RestController}. */
  protected static final String PREFIX = "/api";

  @Override
  public void configurePathMatch(PathMatchConfigurer configurer) {
    configurer.addPathPrefix(PREFIX, c -> c.isAnnotationPresent(RestController.class));
  }
}
