package com.commerzbank.pumba.configuration.security;

import static com.commerzbank.frame.security.spring.config.AuthorizationDefaultConfiguration.AUTHORITY;

import com.commerzbank.frame.security.authorization.AuthorizationAuthority;
import com.commerzbank.frame.security.spring.oauth2.server.resource.authentication.JwtComAusGrantedAuthoritiesConverter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.session.NullAuthenticatedSessionStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;

/**
 * Security configuration for JWS providers acting as OAuth2 resource servers.
 *
 * @author FRAME
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class OAuth2ResourceServerSecurityConfiguration {
  /**
   * {@link AuthorizationAuthority} to retrieve the user's roles and permissions for this
   * application. For internal use cases the default, i.e. the authority for the ComAus
   * authorization system is in use.
   */
  public AuthorizationAuthority authority;

  /**
   * Creates this OAuth2 related security configuration using the given {@link
   * AuthorizationAuthority} for the purpose of application authorization. By default, the authority
   * associated with the ComAus system is used.
   *
   * @param authority {@link AuthorizationAuthority} in use, defaulting to the ComAus authority.
   */
  public OAuth2ResourceServerSecurityConfiguration(
      @Qualifier(AUTHORITY) AuthorizationAuthority authority) {
    this.authority = authority;
  }

  /**
   * Custom converter grabbing resources from ComAus and converting them to {@link
   * GrantedAuthority}s.
   *
   * <p>This customization is due to Commerzbank's identity provider does not provide
   * roles/permissions from ComAus via scope attributes of issued JWTs.
   *
   * @return The granted authorities converter for the ComAus system.
   */
  @Bean
  public JwtComAusGrantedAuthoritiesConverter jwtComAusGrantedAuthoritiesConverter() {
    return new JwtComAusGrantedAuthoritiesConverter(authority);
  }

  /**
   * JWT authentication converter using {@link JwtComAusGrantedAuthoritiesConverter} for the
   * conversion ComAus resources to {@link GrantedAuthority}s.
   *
   * @return The JWT authentication converter using {@link JwtComAusGrantedAuthoritiesConverter} for
   *     conversions.
   */
  @Bean
  public JwtAuthenticationConverter jwtAuthenticationConverter() {
    final var converter = new JwtAuthenticationConverter();
    converter.setJwtGrantedAuthoritiesConverter(jwtComAusGrantedAuthoritiesConverter());
    return converter;
  }

  /**
   * Provides a session authentication strategy bean which should be of type {@link
   * NullAuthenticatedSessionStrategy} for bearer-only applications.
   *
   * @return The configured {@link NullAuthenticatedSessionStrategy}.
   */
  @Bean
  protected SessionAuthenticationStrategy sessionAuthenticationStrategy() {
    return new NullAuthenticatedSessionStrategy();
  }

  /**
   * Defines the {@link SecurityFilterChain} matching {@code HttpServletRequest}s for this
   * OAuth2-secured application in configuring its {@link HttpSecurity}.
   *
   * @param http The {@link HttpSecurity} to be modified.
   * @return The properly configured {@link SecurityFilterChain}.
   * @throws Exception If an error occurs.
   */
  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http.sessionManagement(
            sessionManagement ->
                sessionManagement
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                    .sessionAuthenticationStrategy(sessionAuthenticationStrategy()))
        .authorizeRequests(authorize -> authorize.antMatchers("/api/**").authenticated())
        .oauth2ResourceServer(
            oauth2Server ->
                oauth2Server.jwt().jwtAuthenticationConverter(jwtAuthenticationConverter()))
        .cors();

    return http.build();
  }

  /**
   * As access to the resources beneath path {@code /api} of this resource server is secured, it
   * expects a valid OAuth 2.0 access token sent by the calling client application to work.
   * Otherwise access to these protected resources is denied. Since clients at the start of a
   * project are often not yet registered in the API portal as OAuth 2.0 clients, they do not send
   * an access token along with a request, so their calls will fail. For this case, we provide this
   * workaround for the Spring profile {@code local} bypassing OAuth2 security.
   *
   * <p>This workaround should be immediately removed as soon as calls to the secured resources of
   * this server can be made with valid access tokens!
   *
   * @return The {@link WebSecurityCustomizer} allowing to bypass OAuth2 security.
   */
  @Profile(value = {"local"})
  @Bean
  public WebSecurityCustomizer webSecurityCustomizer() {
    return web -> web.ignoring().antMatchers("/api/**");
  }
}
