package com.commerzbank.pumba.configuration;

import com.commerzbank.frame.jws.rest.RestStandards;
import com.commerzbank.frame.jws.rest.reactive.client.WebClientStandardsCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServletOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * Configuration for a customized {@link WebClient} for usage in OAuth 2.0 secured applications,
 * which follow the CoBa REST standards with regard to their traceability and security demands.
 *
 * @author FRAME
 */
@Configuration
public class WebClientConfiguration {
  /**
   * Creates the {@link WebClient} following the CoBa REST standards. Therefore, it uses the {@link
   * WebClient.Builder} customized to support the traceability requirements of the standards (see
   * {@link WebClientStandardsCustomizer}) and defaults the {@link OAuth2AuthorizedClient} in use in
   * discovering it from the current authentication (see <a
   * href="https://docs.spring.io/spring-security/reference/servlet/oauth2/client/authorized-clients.html#_defaulting_the_authorized_client">defaulting
   * the authorized client</a> for more information), to add the OAuth2 access token to each client
   * request to support the REST standards' security demands.
   *
   * <p>Please note that there is more than one way to provide the authorized client to the {@link
   * ServletOAuth2AuthorizedClientExchangeFilterFunction} as described at <a
   * href="https://docs.spring.io/spring-security/reference/servlet/oauth2/client/authorized-clients.html#_providing_the_authorized_client">providing
   * the authorized client</a>.
   *
   * @param authorizedClientRepository The repository of authorized clients.
   * @param clientRegistrationRepository The OAuth2 client registration repository in use containing
   *     all client registrations.
   * @param builder The {@link WebClient.Builder} to be customized by the {@link
   *     WebClientStandardsCustomizer} and the appropriate exchange filter function to add the
   *     OAuth2 access token as HTTP {@code Authorization} header to each client request.
   * @param restStandards The {@link RestStandards} default implementation used by the {@link
   *     WebClientStandardsCustomizer}. It provides the necessary traceability HTTP headers (global
   *     request id and client machine name) of the CoBa REST standards to each client request.
   * @return The completely configured {@link WebClient} following the CoBa REST standards.
   */
  @Bean
  public WebClient webClient(
      OAuth2AuthorizedClientRepository authorizedClientRepository,
      ClientRegistrationRepository clientRegistrationRepository,
      WebClient.Builder builder,
      RestStandards restStandards) {
    var oauth2Client =
        new ServletOAuth2AuthorizedClientExchangeFilterFunction(
            clientRegistrationRepository, authorizedClientRepository);
    oauth2Client.setDefaultOAuth2AuthorizedClient(true);

    // customizes builder regarding standards' traceability demands
    new WebClientStandardsCustomizer(restStandards).customize(builder);

    return builder.apply(oauth2Client.oauth2Configuration()).build();
  }
}
