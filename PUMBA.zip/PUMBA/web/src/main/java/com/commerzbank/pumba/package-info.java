/** This package includes the application showing best practices in development using FRAME. */
package com.commerzbank.pumba;
