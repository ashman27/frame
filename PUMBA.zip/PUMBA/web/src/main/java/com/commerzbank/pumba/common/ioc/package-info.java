/** Contains the application specific classes handling with Spring's IoC functionality. */
package com.commerzbank.pumba.common.ioc;
