/** Contains application specific exceptions and corresponding handlers. */
package com.commerzbank.pumba.common.exception;
