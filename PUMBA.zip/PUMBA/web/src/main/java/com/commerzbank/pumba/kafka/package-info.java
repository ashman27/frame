/** Classes representing Kafka Consumer and / or Kafka Producer example. */
package com.commerzbank.pumba.kafka;
