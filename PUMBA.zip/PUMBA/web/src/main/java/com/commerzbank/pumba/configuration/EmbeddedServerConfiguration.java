package com.commerzbank.pumba.configuration;

import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.util.scan.StandardJarScanner;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration relevant if running the application on an embedded Tomcat runtime.
 *
 * @author FRAME
 */
@Configuration
public class EmbeddedServerConfiguration {
  /**
   * Factory creating this embedded Tomcat runtime, which is at least enabled for JNDI naming and
   * has scanning of JAR manifests disabled.
   *
   * @return A properly configured embedded Tomcat instance.
   */
  @Bean
  public ServletWebServerFactory tomcatFactory() {
    return new TomcatServletWebServerFactory() {
      @Override
      protected TomcatWebServer getTomcatWebServer(Tomcat tomcat) {
        tomcat.enableNaming();
        return new TomcatWebServer(tomcat, getPort() >= 0);
      }

      @Override
      protected void postProcessContext(Context context) {
        // comment in case JAR scanning is desired
        ((StandardJarScanner) context.getJarScanner()).setScanManifest(false);
      }
    };
  }
}
