package com.commerzbank.pumba.configuration;

import java.io.IOException;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * This is a local helper class, for the default Kafka setup, to make the project buildable. The
 * property 'schema.registry.ssl.truststore.location', in the application.yaml, requires the same
 * value as the 'spring.kafka.ssl.trust-store-location' property, but the difference is that the
 * 'spring.kafka.ssl.trust-store-location' property can be determined at the application start and
 * the 'schema.registry.ssl.truststore.location' have to be an absolut path value that could not be
 * determined. This local solution moves the determined value from the
 * 'spring.kafka.ssl.trust-store-location' property to the 'spring.kafka.ssl.trust-store-location'
 * property.
 *
 * @author FRAME
 */
@Configuration
@Profile(value = {"local"})
public class LocalKafkaConfiguration {

  static final String PROP_TRUST_STORE_LOCATION = "schema.registry.ssl.truststore.location";

  public LocalKafkaConfiguration(KafkaProperties kafkaProperties) throws IOException {
    var location = kafkaProperties.getProperties().get(PROP_TRUST_STORE_LOCATION);
    if (location == null || location.isEmpty()) {
      var sslLocation =
          kafkaProperties.getSsl().getTrustStoreLocation().getFile().getAbsolutePath();
      kafkaProperties.getProperties().replace(PROP_TRUST_STORE_LOCATION, sslLocation);
    }
  }
}
