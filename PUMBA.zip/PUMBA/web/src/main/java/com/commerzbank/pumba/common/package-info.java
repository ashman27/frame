/** Classes representing the common layer of the application. */
package com.commerzbank.pumba.common;
