/** Contains the application specific property sources. */
package com.commerzbank.pumba.common.ioc.sources;
